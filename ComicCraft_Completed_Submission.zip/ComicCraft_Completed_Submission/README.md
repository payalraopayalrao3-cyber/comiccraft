# ComicCraft – AI Comic Story Creator

Completed 8-folder project submission for ComicCraft.

## Working application
`5. Project Development Phase/ComicCraft/`

## Run
1. Open the ComicCraft folder in VS Code.
2. Create a virtual environment and install `requirements.txt`.
3. Copy `.env.example` to `.env`.
4. Use `IMAGE_BACKEND=mock` for the first local UI test.
5. Run `python -m uvicorn app.main:app --reload`.
6. Open `http://127.0.0.1:8000`.

Do not commit real API keys.

## Team
- N Anushyashree
- S Rithika
- Payal Rao
