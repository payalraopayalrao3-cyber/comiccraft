from functools import lru_cache
from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent

class Settings(BaseSettings):
    app_name: str = "ComicCraft"
    environment: str = "development"
    gemini_api_key: str = ""
    gemini_flash_model: str = "gemini-3.6-flash"
    gemini_pro_model: str = "gemini-3.6-flash"
    gemini_retry_attempts: int = 4
    gemini_retry_base_seconds: float = 2.0
    image_backend: str = "mock"
    hf_token: str = ""
    image_model_id: str = "stabilityai/stable-diffusion-3.5-large-turbo"
    local_diffusers_model: str = "runwayml/stable-diffusion-v1-5"
    image_width: int = 768
    image_height: int = 512
    image_steps: int = 20
    image_guidance_scale: float = 7.0
    max_prompt_length: int = 1200
    max_character_length: int = 80
    max_setting_length: int = 120
    model_config = SettingsConfigDict(
        env_file=BASE_DIR / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

@lru_cache
def get_settings() -> Settings:
    return Settings()
