from app.config import get_settings
from app.services.gemini_client import generate_json


def generate_outline(prompt: str) -> dict:
    settings = get_settings()
    return generate_json(prompt, model=settings.gemini_flash_model)
