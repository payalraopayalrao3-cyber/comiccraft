from pathlib import Path
from fpdf import FPDF
from app.schemas import ComicDocument

BASE_DIR = Path(__file__).resolve().parents[2]
EXPORT_DIR = BASE_DIR / "static" / "exports"
EXPORT_DIR.mkdir(parents=True, exist_ok=True)


def _local_image(path: str) -> str:
    return str(BASE_DIR / path.removeprefix("/static/"))


def export_pdf(comic: ComicDocument) -> str:
    path = EXPORT_DIR / f"{comic.comic_id}.pdf"
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.set_title("ComicCraft")
    for panel in comic.panels:
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 18)
        pdf.cell(0, 10, f"Panel {panel.panel_number}: {panel.title}", ln=True)
        image_file = _local_image(panel.image_path) if hasattr(panel, "image_path") else None
        if image_file and Path(image_file).exists():
            pdf.image(image_file, x=15, y=30, w=180)
            pdf.set_y(140)
        pdf.set_font("Helvetica", size=11)
        pdf.multi_cell(0, 7, panel.scene_description)
        pdf.ln(2)
        pdf.multi_cell(0, 7, f"Caption: {panel.caption}")
        pdf.multi_cell(0, 7, f"Narration: {panel.narration}")
    pdf.output(str(path))
    return "/static/exports/" + path.name
