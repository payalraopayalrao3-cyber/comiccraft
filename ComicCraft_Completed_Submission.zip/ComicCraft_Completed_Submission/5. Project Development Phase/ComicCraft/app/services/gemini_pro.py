from app.config import get_settings
from app.services.gemini_client import generate_json


def expand_story(prompt: str) -> dict:
    settings = get_settings()
    return generate_json(prompt, model=settings.gemini_pro_model)
