import json
import uuid
from pathlib import Path

from app.config import get_settings
from app.schemas import ComicDocument, ComicRequest, StoryPanel
from app.services.gemini_flash import generate_outline
from app.services.gemini_pro import expand_story
from app.services.image_generator import generate_image
from app.services.exporters import export_pdf

BASE_DIR = Path(__file__).resolve().parents[2]
COMICS_DIR = BASE_DIR / "static" / "comics"
COMICS_DIR.mkdir(parents=True, exist_ok=True)


def _mock_panels(request: ComicRequest):
    stages = ["Beginning", "Discovery", "Challenge", "Climax", "Resolution"]
    return [
        {"panel_number": i + 1, "title": stages[i],
         "scene_description": f"{request.character_name} in {request.setting}: {request.story_prompt}",
         "image_prompt": f"{request.art_style} comic panel, {request.character_name}, {request.setting}, {request.tone}, panel {i+1}, {request.story_prompt}",
         "caption": f"Panel {i+1} of the adventure.",
         "narration": f"{request.character_name} moves the story forward in this {request.tone} scene."}
        for i in range(5)
    ]


def _ai_panels(request: ComicRequest):
    outline_prompt = f"""Create exactly five comic panel outlines as JSON. Return an object with key 'panels', an array of five objects with keys panel_number,title,scene_description,image_prompt. Story: {request.story_prompt}. Character: {request.character_name}. Setting: {request.setting}. Tone: {request.tone}. Art style: {request.art_style}."""
    outline = generate_outline(outline_prompt)
    panels = outline.get("panels")
    if not isinstance(panels, list) or len(panels) != 5:
        raise RuntimeError("Gemini outline must contain exactly five panels.")
    story_prompt = f"""Expand these five comic panels into concise comic copy. Return JSON with key 'panels', five objects containing panel_number,title,scene_description,image_prompt,caption,narration. Keep the same five panel numbers and titles. Input: {json.dumps(panels)}"""
    expanded = expand_story(story_prompt)
    result = expanded.get("panels")
    if not isinstance(result, list) or len(result) != 5:
        raise RuntimeError("Gemini story response must contain exactly five panels.")
    return result


def generate_comic(request: ComicRequest) -> ComicDocument:
    settings = get_settings()
    comic_id = uuid.uuid4().hex[:12]
    raw_panels = _mock_panels(request) if not settings.gemini_api_key else _ai_panels(request)
    panels: list[StoryPanel] = []
    for index, raw in enumerate(raw_panels[:5]):
        image_path = generate_image(str(raw["image_prompt"]), index)
        panels.append(StoryPanel(
            panel_number=index + 1,
            title=str(raw.get("title", f"Panel {index + 1}")),
            scene_description=str(raw.get("scene_description", "")),
            image_prompt=str(raw.get("image_prompt", "")),
            caption=str(raw.get("caption", "")),
            narration=str(raw.get("narration", "")),
            image_path=image_path,
        ))
    comic = ComicDocument(comic_id=comic_id, request=request, panels=panels)
    comic = comic.model_copy(update={"pdf_path": export_pdf(comic)})
    (COMICS_DIR / f"{comic_id}.json").write_text(comic.model_dump_json(indent=2), encoding="utf-8")
    return comic


def load_comic(comic_id: str) -> ComicDocument:
    path = COMICS_DIR / f"{comic_id}.json"
    if not path.exists():
        raise FileNotFoundError("Comic not found.")
    return ComicDocument.model_validate_json(path.read_text(encoding="utf-8"))
