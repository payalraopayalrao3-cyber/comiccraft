from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

from app.config import get_settings

BASE_DIR = Path(__file__).resolve().parents[2]
PANELS_DIR = BASE_DIR / "static" / "panels"
PANELS_DIR.mkdir(parents=True, exist_ok=True)


def _font(size: int):
    candidates = [
        "C:/Windows/Fonts/arial.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]
    for path in candidates:
        if Path(path).exists():
            return ImageFont.truetype(path, size)
    return ImageFont.load_default()


def _mock_image(prompt: str, index: int) -> Path:
    settings = get_settings()
    path = PANELS_DIR / f"mock_{index + 1}.png"
    image = Image.new("RGB", (settings.image_width, settings.image_height), "#f3efe5")
    draw = ImageDraw.Draw(image)
    draw.rectangle((18, 18, settings.image_width - 18, settings.image_height - 18), outline="#222", width=4)
    draw.text((45, 45), f"COMIC PANEL {index + 1}", fill="#111", font=_font(30))
    text = prompt[:260]
    y = 115
    words = text.split()
    line = ""
    for word in words:
        candidate = (line + " " + word).strip()
        if draw.textlength(candidate, font=_font(22)) > settings.image_width - 90:
            draw.text((45, y), line, fill="#333", font=_font(22))
            y += 34
            line = word
        else:
            line = candidate
        if y > settings.image_height - 60:
            break
    if line and y <= settings.image_height - 60:
        draw.text((45, y), line, fill="#333", font=_font(22))
    image.save(path)
    return path


def generate_image(prompt: str, index: int) -> str:
    settings = get_settings()
    backend = settings.image_backend.lower().strip()
    if backend == "mock":
        path = _mock_image(prompt, index)
        return "/static/panels/" + path.name
    if backend == "huggingface":
        try:
            from huggingface_hub import InferenceClient
        except ImportError as exc:
            raise RuntimeError("huggingface-hub is not installed.") from exc
        if not settings.hf_token:
            raise RuntimeError("HF_TOKEN is not configured for Hugging Face image generation.")
        client = InferenceClient(token=settings.hf_token)
        image = client.text_to_image(
            prompt,
            model=settings.image_model_id,
            width=settings.image_width,
            height=settings.image_height,
        )
        path = PANELS_DIR / f"panel_{index + 1}.png"
        image.save(path)
        return "/static/panels/" + path.name
    if backend == "diffusers":
        try:
            from diffusers import StableDiffusionPipeline
            import torch
        except ImportError as exc:
            raise RuntimeError("Install diffusers and torch for IMAGE_BACKEND=diffusers.") from exc
        device = "cuda" if torch.cuda.is_available() else "cpu"
        pipe = StableDiffusionPipeline.from_pretrained(settings.local_diffusers_model)
        pipe = pipe.to(device)
        result = pipe(prompt, num_inference_steps=settings.image_steps, guidance_scale=settings.image_guidance_scale)
        path = PANELS_DIR / f"panel_{index + 1}.png"
        result.images[0].save(path)
        return "/static/panels/" + path.name
    raise RuntimeError(f"Unknown IMAGE_BACKEND: {settings.image_backend}")
