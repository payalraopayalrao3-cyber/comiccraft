import json
import time
from typing import Any

from google import genai
from google.genai import types

from app.config import get_settings


def _extract_text(response: Any) -> str:
    text = getattr(response, "text", None)
    if text:
        return text.strip()
    candidates = getattr(response, "candidates", None) or []
    for candidate in candidates:
        content = getattr(candidate, "content", None)
        parts = getattr(content, "parts", None) if content else None
        for part in parts or []:
            value = getattr(part, "text", None)
            if value:
                return value.strip()
    raise RuntimeError("Gemini returned an empty response.")


def generate_json(prompt: str, *, model: str) -> dict:
    settings = get_settings()
    if not settings.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY is not configured.")

    client = genai.Client(api_key=settings.gemini_api_key)
    last_error: Exception | None = None
    for attempt in range(settings.gemini_retry_attempts):
        try:
            response = client.models.generate_content(
                model=model,
                contents=prompt,
                config=types.GenerateContentConfig(
                    temperature=0.8,
                    response_mime_type="application/json",
                ),
            )
            raw = _extract_text(response)
            try:
                return json.loads(raw)
            except json.JSONDecodeError as exc:
                raise RuntimeError(f"Gemini returned invalid JSON: {raw[:500]}") from exc
        except Exception as exc:
            last_error = exc
            message = str(exc).lower()
            transient = any(code in message for code in ("503", "unavailable", "429", "resource exhausted", "temporarily"))
            if not transient or attempt == settings.gemini_retry_attempts - 1:
                raise
            time.sleep(settings.gemini_retry_base_seconds * (2 ** attempt))
    raise RuntimeError(str(last_error) if last_error else "Gemini request failed.")
