# ComicCraft — fixed project

This version restores the missing `app/` package, services, templates, static folders and `requirements.txt` that the supplied archive referenced.

## First run (recommended)
1. Open this folder in VS Code.
2. Open PowerShell in the project folder.
3. Run `py -m venv .venv` if `.venv` does not exist.
4. Run `.venv\Scripts\python.exe -m pip install -r requirements.txt`.
5. Copy `.env.example` to `.env`.
6. Keep `IMAGE_BACKEND=mock` for the first UI test.
7. Run `.venv\Scripts\python.exe -m uvicorn app.main:app --reload`.
8. Open http://127.0.0.1:8000 and test Generate Comic.

The mock mode does not require Gemini or Hugging Face. After the full pipeline works, add your own API keys and switch `IMAGE_BACKEND` as needed.

For Gemini 503 responses, the Gemini client retries transient 503/429/unavailable errors with exponential backoff. Model IDs remain configurable in `.env` because model availability can change.
